import { Hero } from "@/components/landing/Hero";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950">
      <Hero />
    </main>
  );
}
