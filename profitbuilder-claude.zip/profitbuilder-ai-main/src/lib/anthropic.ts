export const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
export const DEFAULT_MODEL = "claude-sonnet-4-20250514";

export async function callClaude(systemPrompt: string, userPrompt: string): Promise<string> {
  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY!,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: DEFAULT_MODEL,
      max_tokens: 4096,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Anthropic API error: ${response.status} - ${error}`);
  }

  const data = await response.json();
  return data.content[0].text;
}

export function parseClaudeResponse<T>(content: string): T {
  if (!content) throw new Error("No content received from Claude");
  try {
    let clean = content.trim();
    clean = clean.replace(/^```json\n?/, "").replace(/^```\n?/, "");
    clean = clean.replace(/\n?```$/, "");
    // Extract JSON object if there's surrounding text
    const match = clean.match(/\{[\s\S]*\}/);
    if (match) clean = match[0];
    return JSON.parse(clean) as T;
  } catch (error) {
    console.error("Failed to parse JSON from Claude:", content);
    throw new Error("Failed to parse the structured response from the AI.");
  }
}
