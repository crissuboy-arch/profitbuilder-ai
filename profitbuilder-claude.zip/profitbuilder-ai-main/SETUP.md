# ProfitBuilder AI - Setup (Claude Version)

## O que foi alterado
- Removido: OpenAI (gpt-4o-mini)
- Adicionado: Claude (claude-sonnet via API Anthropic)
- Todos os módulos agora usam `src/lib/anthropic.ts`

## Como configurar

### 1. Chave do Claude (Anthropic)
- Acesse: https://console.anthropic.com
- Vá em "API Keys" → "Create Key"
- Copie a chave (começa com `sk-ant-...`)

### 2. Supabase (banco de dados)
- Acesse: https://supabase.com
- Crie um projeto gratuito
- Vá em Settings → API → copie URL e anon key
- Execute o arquivo `supabase_schema.sql` no SQL Editor do Supabase

### 3. Variáveis de ambiente no Vercel
No painel do seu projeto no Vercel:
Settings → Environment Variables → adicione:

```
ANTHROPIC_API_KEY=sk-ant-SUA_CHAVE_AQUI
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

### 4. Redeploy
Após adicionar as variáveis → clique em "Redeploy"

## Rodar localmente
```bash
cp .env.example .env.local
# Edite .env.local com suas chaves
npm install
npm run dev
```
